void readfile(FILE *f);
void process_request(FILE *f);
